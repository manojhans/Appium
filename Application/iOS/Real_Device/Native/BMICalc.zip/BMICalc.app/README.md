# BMICalc iOS App

## By Soroush Pour

This is a simple Body Mass Index calculator app for the iPhone, written in Objective-C in Xcode 4.6.

- Calculate Body Mass Index
- Use SI (metres, kilograms) or EE (feet-inches, pounds) units
- Saves unit settings across app launches using NSUserDefaults
